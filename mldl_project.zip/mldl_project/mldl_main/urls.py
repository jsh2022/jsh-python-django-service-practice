from django.urls import path, include
from . import views
from django.conf import settings
from django.conf.urls.static import static


app_name = 'mldl_main'

urlpatterns = [
    path('', views.index, name='index'),

    path('ml_diabetes/', views.ml_diabetes, name='ml_diabetes'),
    path('ml_diabetes/predict/', views.predict_diabetes, name='predict_diabetes_ml'),

    path('dl_diabetes/', views.dl_diabetes, name='dl_diabetes'),
    path('dl_diabetes/predict/', views.predict_diabetes, name='predict_diabetes_dl'),
    path('dl_diabetes/delete/<str:file_name>/', views.delete_diabetes, name='delete_diabetes'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
