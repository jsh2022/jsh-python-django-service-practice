from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import pandas as pd
import numpy as np
from .predict_ML import predict_diabetes_ml
from .predict_DL import predict_diabetes_dl

# Create your views here.

def index(request):
    return render(request, 'mldl_main/index.html', {})


def ml_diabetes(request):
    return render(request, 'mldl_main/ml_diabetes.html', {})

def predict_diabetes(request):

    age = float(request.POST['age']) if request.POST['age'] != '' else 25
    glucose  = float(request.POST['glucose'])  if request.POST['glucose']  != '' else 110
    bmi = float(request.POST['bmi']) if request.POST['bmi'] != '' else 23.41

    user_input = pd.DataFrame([[glucose, bmi, age]], columns=['Glucose', 'BMI', 'age'])
    
    predict_result = predict_diabetes_ml(user_input)

    context = {'predict_result' : predict_result}
    return render(request, 'mldl_main/ml_diabetes_result.html', context)


def dl_diabetes(request):
    return render(request, 'mldl_main/dl_diabetes.html', {})

def predict_diabetes_dl(request):

    # uploaded_file = request.FILES['img_uploaded']

    # # OpenCV error occurs when file's name has Korean character or white-spaces
    # uploaded_file.name = uploaded_file.name.replace(' ', '')

    # fs = FileSystemStorage()
    # uploaded_filename = fs.save(uploaded_file.name, uploaded_file)
    # uploaded_file_url = fs.url(uploaded_filename) # "/media/~~~.jpg"

    # predict_result = predict_diabetes_two(settings.MEDIA_ROOT_URL + uploaded_file_url)

    # context = {'uploaded_file_url':uploaded_file_url,
    #            'uploaded_file_name':uploaded_filename,
    #            'predict_result' : predict_result}

    age = float(request.POST['age']) if request.POST['age'] != '' else 25
    glucose  = float(request.POST['glucose'])  if request.POST['glucose']  != '' else 110
    bmi = float(request.POST['bmi']) if request.POST['bmi'] != '' else 23.41

    # user_input = pd.DataFrame([[glucose, bmi, age]], columns=['Glucose', 'BMI', 'age'])
    user_input = np.array([[glucose, bmi, age]])
    predict_result = predict_diabetes_dl(user_input)

    context = {'predict_result' : predict_result}
    return render(request, 'mldl_main/dl_diabetes_result.html', context)


def delete_diabetes(request, file_name):

    fs = FileSystemStorage()
    fs.delete(file_name)

    return redirect('mldl_main:index')
