from django.conf import settings
from tensorflow.keras.models import load_model
import numpy as np

def predict_diabetes_dl(user_input):
    # 모델 경로 설정
    base_url = settings.MEDIA_ROOT_URL + settings.MEDIA_URL # == './media/'
    model_url = base_url + 'DL_tuner_trained_model.h5' #./media/DL_tuner_trained_model.h5
    
    # 모델 로드
    model_loaded = load_model(model_url)
    
    # 데이터 전처리 (예: scaling, reshaping)
    # user_input = np.array(user_input).reshape(1, -1)  # 모델이 2D array를 입력으로 요구하는 경우
    
    # 예측 수행
    result_class = model_loaded.predict(user_input) # ex) array([[0.1, 0.9]])
    
    # 클래스 결정
    result_class = np.argmax(result_class)  # 예: 1
    
    target_names = ['Negative', 'Positive']
    predict_result = target_names[result_class]
    
    return predict_result
