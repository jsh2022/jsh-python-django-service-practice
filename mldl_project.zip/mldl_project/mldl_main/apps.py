from django.apps import AppConfig


class MldlMainConfig(AppConfig):
    name = 'mldl_main'
